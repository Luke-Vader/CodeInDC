package com.example.lab4;

import com.example.lab4.model.Student;
import com.example.lab4.repositories.StudentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Date;

@SpringBootApplication
public class Lab4Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab4Application.class, args);
    }

    @Bean
    CommandLineRunner runner(StudentRepository studentRepository) {
        return args -> {
//            studentRepository.save(new Student(null, "Jam", new Date(), false, 1.2));
//            studentRepository.save(new Student(null, "Joe", new Date(), true, 3.2));
//            studentRepository.save(new Student(null, "John", new Date(), true, 3.8));
//            studentRepository.save(new Student(null, "Jim", new Date(), false, 2.2));

            studentRepository.findAll().forEach(p -> {
                System.out.println(p.getName());
            });
        };
    }

}
